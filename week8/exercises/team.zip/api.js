import SwapiController from './SwapiController.js';

const swapiController = new SwapiController('result');

swapiController.showResult();
