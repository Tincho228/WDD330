import QuakesController from './QuakesController.js';

import { getJSON, getLocation } from './utilities.js';


const quakescontroller = new QuakesController('#quakeList');
quakescontroller.init();




