import Hikes from "./hikes.js";

const myHike = new Hikes('hikes');

myHike.showHikeList();
